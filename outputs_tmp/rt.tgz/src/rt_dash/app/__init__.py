"""Aplicação Dash."""
